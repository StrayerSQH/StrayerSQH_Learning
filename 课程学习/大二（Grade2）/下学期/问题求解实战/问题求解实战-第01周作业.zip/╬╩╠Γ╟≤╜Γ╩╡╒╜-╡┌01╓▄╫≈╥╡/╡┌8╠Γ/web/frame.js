// 获取绿色区域和文字元素
const rightArea = document.getElementById('right');
const rightText = document.getElementById('right-text');
const leftText = document.getElementById('left-text');
const topArea = document.getElementById('top');
const leftArea = document.getElementById('left');

// 监听绿色区域的点击事件
rightArea.addEventListener('click', function (event) {
    // 阻止事件冒泡，避免点击绿色区域时触发其他区域的点击事件
    event.stopPropagation();
    // 显示文字
    rightText.style.display = 'flex';
    // 设置 2 秒后自动隐藏文字
    setTimeout(function () {
        rightText.style.display = 'none';
    }, 2000); // 2000 毫秒 = 2 秒
});

topArea.addEventListener('click', function(event) {
    event.stopPropagation();
    leftArea.style.display = 'flex'; // 显示 left 区域
    leftText.style.display = 'flex'; // 显示 left 区域的文本
    rightArea.style.width = "80%"; // 调整 right 区域的宽度
});

leftArea.addEventListener('click',function(event){
    event.stopPropagation();
    leftArea.style.display = 'none';
    rightArea.style.width = "100%";
});