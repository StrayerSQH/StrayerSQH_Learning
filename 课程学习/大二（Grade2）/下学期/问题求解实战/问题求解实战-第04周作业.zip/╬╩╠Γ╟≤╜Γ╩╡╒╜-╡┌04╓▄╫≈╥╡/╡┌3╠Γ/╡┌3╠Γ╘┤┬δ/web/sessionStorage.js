function saveToSessionStorage()
{
    const userInput = document.getElementById("userInput1").value;
    if (userInput)
    {
        sessionStorage.setItem("savedInput", userInput);
        alert("数据已经保存到 sessionStorage!");
    }
}
