package com;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import java.io.PrintWriter;
import java.io.IOException;
import org.json.JSONObject;
import org.json.JSONException;

public class GetSessionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String savedInput = (session != null) ? (String) session.getAttribute("savedInput") : null;

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            JSONObject json = new JSONObject();
            try {
                if(savedInput != null) {
                    json.put("savedInput", savedInput);
                }
                out.print(json.toString());
            } catch (JSONException e) {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print("{\"error\":\"JSON processing failed\"}");
                // 实际项目中应该使用日志框架记录错误
                e.printStackTrace();
            }
        }
    }
}