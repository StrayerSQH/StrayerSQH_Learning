function saveToLocalStorage()
{
    const userInput = document.getElementById("userInput").value;

    if (userInput.trim() === "") {
        alert("输入内容不能为空！");
        return;
    }
    localStorage.setItem("savedData", userInput);

    alert("数据已保存到 localStorage！");
}
