package device.dao;

import org.json.JSONObject;

public class Data {
	private JSONObject param=new JSONObject();

	public JSONObject getParam() {
		return param;
	}

	public void setParam(JSONObject param) {
		this.param = param;
	}

}
