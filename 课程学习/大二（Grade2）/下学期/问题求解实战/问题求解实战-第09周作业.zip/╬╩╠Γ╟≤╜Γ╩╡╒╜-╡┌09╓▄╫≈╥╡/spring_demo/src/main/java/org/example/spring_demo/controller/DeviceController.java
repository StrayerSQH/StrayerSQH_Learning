package org.example.spring_demo.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.example.spring_demo.dao.DeviceDao;
import org.example.spring_demo.entity.Device;
import org.example.spring_demo.service.DeviceService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;

@RestController
@RequestMapping("/device")
public class DeviceController {
    @RequestMapping("/get_record")
    public JSONObject getDeviceRecord(@RequestBody(required = false) JSONObject param) throws SQLException {
        System.out.println("[DeviceController/get_record]执行到这里了!");
        JSONObject json = new JSONObject(); //待返回的数据
        DeviceService service = new DeviceService();    //调用service层
        if (param == null) {
            param = new JSONObject();
            param.put("time", JSON.toJSONStringWithDateFormat(new java.util.Date(), "yyyy-MM-dd HH:mm:ss"));
        }
        service.getDeviceRecord(param, json);
        return json;
    }

    @RequestMapping("/add_record")
    public JSONObject addDeviceRecord(@RequestBody(required = false) Device device) throws SQLException {
        System.out.println("[DeviceController/add_record]"+device.toString());
        JSONObject json = new JSONObject(); //待返回的数据
        DeviceService service = new DeviceService();    //调用service层
        service.addDeviceRecord(device, json);
        return json;
    }
}
