package org.example.spring_demo.service;

import com.alibaba.fastjson.JSONObject;
import org.example.spring_demo.dao.DeviceDao;
import org.example.spring_demo.entity.Device;

import java.sql.SQLException;

public class DeviceService {
    public void getDeviceRecord(JSONObject param, JSONObject json) throws SQLException {
        System.out.println("[Service/getDeviceRecord]执行到这里:param:"+param.toString());
        DeviceDao dao = new DeviceDao();    //调用dao层
        dao.getDeviceRecord(param, json);
    }

    public void addDeviceRecord(Device device, JSONObject json) throws SQLException {
        System.out.println("[Service/addDeviceRecord]执行到这里:device:"+device.toString());
        DeviceDao dao = new DeviceDao();    //调用dao层
        dao.addDeviceRecord(device, json);
    }
}
