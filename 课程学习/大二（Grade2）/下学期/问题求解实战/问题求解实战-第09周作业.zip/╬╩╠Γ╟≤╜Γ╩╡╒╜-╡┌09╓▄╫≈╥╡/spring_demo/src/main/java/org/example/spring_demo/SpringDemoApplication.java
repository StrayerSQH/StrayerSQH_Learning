package org.example.spring_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("org.example.spring_demo.controller")
@ComponentScan("org.example.spring_demo.dao")
@ComponentScan("org.example.spring_demo.service")
@ComponentScan("org.example.spring_demo.entity")
public class SpringDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDemoApplication.class, args);
    }

}
