package org.example.spring_demo;

import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class testController {
    @RequestMapping("/test")
    public String test(){
        System.out.println("[test]执行到这里了!");
        return "Hello World!";
    }
    @RequestMapping("/get_record")
    public JSONObject getRecord() throws ClassNotFoundException, SQLException {
        System.out.println("[get_record]执行到这里了!");
        JSONObject json = new JSONObject();
        // 访问数据库
        String url="jdbc:mysql://localhost:3306/test";
        String username="root";
        String password="751071";
        try{    // 加载数据库驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        Connection connection = null;
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        String sql = "select * from device_file order by device_name";
        List list = new ArrayList();
        ResultSet rs = statement.executeQuery(sql);
        while (rs.next()){
            Map map = new HashMap();
            map.put("device_name",rs.getString("device_name"));
            map.put("device_id",rs.getString("device_id"));
            map.put("device_type",rs.getString("device_type"));
            map.put("create_time",rs.getString("create_time"));
            list.add(map);
        }
        json.put("data",list);
        json.put("code",200);
        json.put("msg","success");
        //
        return json;
    }
}
