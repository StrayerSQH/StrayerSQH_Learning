package org.example.spring_demo.dao;

import com.alibaba.fastjson.JSONObject;
import org.example.spring_demo.entity.Device;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

public class DeviceDao {
    public void getDeviceRecord(JSONObject param, JSONObject json) throws SQLException {
        System.out.println("[Device/getDeviceRecord]执行到这里:param:"+param.toString());
        /*---------------数据库访问 开始---------------------*/
        String url="jdbc:mysql://localhost:3306/test";
        String username="root";
        String password="751071";
        try{    // 加载数据库驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        System.out.println("数据库驱动已加载！！！！！");

        Connection connection = null;
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        String sql = "select * from device_file order by device_name";
        List list = new ArrayList();
        ResultSet rs = null;
        try {
            rs = statement.executeQuery(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        while (rs.next()){
            Map map = new HashMap();
            map.put("device_name",rs.getString("device_name"));
            map.put("device_id",rs.getString("device_id"));
            map.put("device_type",rs.getString("device_type"));
            map.put("create_time",rs.getString("create_time"));
            list.add(map);
        }
        System.out.println("已完成数据库查询！！！！！");

        /*---------------数据库访问 完毕---------------------*/
        json.put("data",list);
        json.put("code",200);
        json.put("msg","success");
        System.out.println("[Device/getDeviceRecord]执行到这里:json:"+json.toString());
    }

    public void addDeviceRecord(Device device, JSONObject json) throws SQLException {
        System.out.println("[Device/addDeviceRecord]执行到这里:device:"+device.toString());
        /*---------------数据库访问 开始---------------------*/
        String url="jdbc:mysql://localhost:3306/test";
        String username="root";
        String password="751071";
        try{    // 加载数据库驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        System.out.println("数据库驱动已加载！！！！！");

        Connection connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        String deviceId = device.getDevice_id();
        String deviceName = device.getDevice_name();
        String deviceType = device.getDevice_type();
        Date date = new Date();
        String createTime = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        String sql = "insert into device_file (device_id,device_name,device_type,create_time) " +
                "values ('"+deviceId+"','"+deviceName+"','"+deviceType+"','"+createTime+"')";
        List list = new ArrayList();
        statement.executeUpdate(sql);

        /*---------------数据库访问 完毕---------------------*/
        json.put("data",list);
        json.put("code",200);
        json.put("msg","success");
    }
}
