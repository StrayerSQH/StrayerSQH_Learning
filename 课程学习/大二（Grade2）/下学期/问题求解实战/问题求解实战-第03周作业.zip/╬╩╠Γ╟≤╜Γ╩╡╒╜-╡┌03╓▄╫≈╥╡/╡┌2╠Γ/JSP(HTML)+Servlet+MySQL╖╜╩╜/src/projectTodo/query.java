package projectTodo;

import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class query extends HttpServlet {
    public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        String action = request.getParameter("action");
        System.out.println("[success][src/projectTodo/query]收到id："+id);
        System.out.println("[success][src/projectTodo/query]收到action："+action);
        String createTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("[success][src/projectTodo/query]加载了驱动");
        } catch (ClassNotFoundException classnotfoundexception)
        {
            //如果有异常就抛出
            classnotfoundexception.printStackTrace();
        }

        List list = new ArrayList();
        try
        {
            System.out.println("[  try  ][src/projectTodo/query]开始链接数据库");
            Connection conn = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/test?user=root&password=123456&useUnicode=true&characterEncoding=UTF-8");
            System.out.println("[success][src/projectTodo/query]链接数据库完毕");

            System.out.println("[  try  ][src/projectTodo/query]开始创建准备数据库操作的statement");
            Statement statement = conn.createStatement();
            System.out.println("[success][src/projectTodo/query]statement创建成功，正式连接到数据库");

            String sql = "";
            System.out.println("[execute][src/projectTodo/query]====================构造SQL 开始====================");
            if (id != null)
            {
                System.out.println("[execute][src/projectTodo/query]====================指定查询id为"+id+"====================");
                sql = "select * from project_todo where id=" + id;
            }
            else
            {
                sql = "select * from project_todo order by create_time";
            }
            System.out.println("[  end  ][src/projectTodo/query]====================构造SQL 结束====================");

            System.out.println("[execute][src/projectTodo/query]执行"+sql);
            ResultSet rs = statement.executeQuery(sql);

            while (rs.next())
            {
                System.out.println("[execute][src/projectTodo/query]====================开始输出====================");
                HashMap map = new HashMap();
                map.put("id", rs.getString("id"));
                map.put("parent_id", rs.getString("parent_id"));
                map.put("object_id", rs.getString("object_id"));
                map.put("title", rs.getString("title"));
                map.put("content", rs.getString("content"));
                map.put("type", rs.getString("type"));
                map.put("limit_time", rs.getString("limit_time"));
                map.put("end_tag", rs.getString("end_tag"));
                map.put("begin_time", rs.getString("begin_time"));
                map.put("end_time", rs.getString("end_time"));
                map.put("executor", rs.getString("executor"));
                map.put("status", rs.getString("status"));
                map.put("attachment_name", rs.getString("attachment_name"));
                map.put("attachment_filename", rs.getString("attachment_filename"));
                map.put("attachment_url", rs.getString("attachment_url"));
                map.put("attachment_size", rs.getString("attachment_size"));
                map.put("attachment_type", rs.getString("attachment_type"));
                map.put("qrcode_url", rs.getString("qrcode_url"));
                map.put("qrcode_file_path_name", rs.getString("qrcode_file_path_name"));
                map.put("top_tag", rs.getString("top_tag"));
                map.put("priority", rs.getString("priority"));
                map.put("user_id", rs.getString("user_id"));
                map.put("check_tag", rs.getString("check_tag"));
                map.put("checker", rs.getString("checker"));
                map.put("check_time", rs.getString("check_time"));
                map.put("used_tag", rs.getString("used_tag"));
                map.put("creator", rs.getString("creator"));
                map.put("creator_id", rs.getString("creator_id"));
                map.put("create_time", rs.getString("create_time"));

                list.add(map);
            }
            statement.close();
            conn.close();
            System.out.println("[  end  ][src/projectTodo/query]statement与conn关闭。所有任务执行完毕。数据库关闭！！！");

        } catch (SQLException sqlexception)
        {
            System.out.println("[  fail  ][src/projectTodo/query]数据库访问出错："+sqlexception.getMessage());
            sqlexception.printStackTrace();
        }

        JSONObject resultJson = new JSONObject();
        try
        {
            resultJson.put("aaData", list);
            resultJson.put("result_code", 0);
            resultJson.put("result_msg", "ok");
        } catch (JSONException e)
        {
            e.printStackTrace();
        }

        response.setContentType("application/json; charset=UTF-8");

        try
        {
            response.getWriter().print(resultJson);
            response.getWriter().flush();
            response.getWriter().close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
