package projectTodo;

import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class delete extends HttpServlet {
    public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        String parent_id = null;
        String object_id = null;
        String title = null;
        String content = null;
        String type = null;
        String limit_time = null;
        String end_tag = null;
        String begin_time = null;
        String end_time = null;
        String executor = null;
        String status = null;
        String attachment_name = null;
        String attachment_filename = null;
        String attachment_url = null;
        String attachment_size = null;
        String attachment_type = null;
        String qrcode_url = null;
        String qrcode_file_path_name = null;
        String top_tag = null;
        String priority = null;
        String user_id = null;
        String check_tag = null;
        String checker = null;
        String check_time = null;
        String used_tag = null;
        String creator = null;
        String creator_id = null;
        String create_time = null;

        System.out.println("[success][src/projectTodo/delete]: 收到id = " + id);
        System.out.println("[success][src/projectTodo/delete]: 收到parent_id = " + parent_id);
        System.out.println("[success][src/projectTodo/delete]: 收到object_id = " + object_id);
        System.out.println("[success][src/projectTodo/delete]: 收到title = " + title);
        System.out.println("[success][src/projectTodo/delete]: 收到content = " + content);
        System.out.println("[success][src/projectTodo/delete]: 收到type = " + type);
        System.out.println("[success][src/projectTodo/delete]: 收到limit_time = " + limit_time);
        System.out.println("[success][src/projectTodo/delete]: 收到end_tag = " + end_tag);
        System.out.println("[success][src/projectTodo/delete]: 收到begin_time = " + begin_time);
        System.out.println("[success][src/projectTodo/delete]: 收到end_time = " + end_time);
        System.out.println("[success][src/projectTodo/delete]: 收到executor = " + executor);
        System.out.println("[success][src/projectTodo/delete]: 收到status = " + status);
        System.out.println("[success][src/projectTodo/delete]: 收到attachment_name = " + attachment_name);
        System.out.println("[success][src/projectTodo/delete]: 收到attachment_filename = " + attachment_filename);
        System.out.println("[success][src/projectTodo/delete]: 收到attachment_url = " + attachment_url);
        System.out.println("[success][src/projectTodo/delete]: 收到attachment_size = " + attachment_size);
        System.out.println("[success][src/projectTodo/delete]: 收到attachment_type = " + attachment_type);
        System.out.println("[success][src/projectTodo/delete]: 收到qrcode_url = " + qrcode_url);
        System.out.println("[success][src/projectTodo/delete]: 收到qrcode_file_path_name = " + qrcode_file_path_name);
        System.out.println("[success][src/projectTodo/delete]: 收到top_tag = " + top_tag);
        System.out.println("[success][src/projectTodo/delete]: 收到priority = " + priority);
        System.out.println("[success][src/projectTodo/delete]: 收到user_id = " + user_id);
        System.out.println("[success][src/projectTodo/delete]: 收到check_tag = " + check_tag);
        System.out.println("[success][src/projectTodo/delete]: 收到checker = " + checker);
        System.out.println("[success][src/projectTodo/delete]: 收到check_time = " + check_time);
        System.out.println("[success][src/projectTodo/delete]: 收到used_tag = " + used_tag);
        System.out.println("[success][src/projectTodo/delete]: 收到creator = " + creator);
        System.out.println("[success][src/projectTodo/delete]: 收到creator_id = " + creator_id);
        System.out.println("[success][src/projectTodo/delete]: 生成create_time = " + create_time);

        String createTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("[success][src/projectTodo/delete]加载了驱动");
        }
        catch (ClassNotFoundException classnotfoundexception)
        {
            classnotfoundexception.printStackTrace();
        }

        List list = new ArrayList();
        try
        {
            System.out.println("[  try  ][src/projectTodo/delete]开始链接数据库");
            Connection conn = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/test?user=root&password=123456&useUnicode=true&characterEncoding=UTF-8");
            System.out.println("[success][src/projectTodo/delete]链接数据库完毕");

            System.out.println("[  try  ][src/projectTodo/delete]开始创建准备数据库操作的statement");
            Statement statement = conn.createStatement();
            System.out.println("[success][src/projectTodo/delete]statement创建成功，正式连接到数据库");

            String sql = "delete from project_todo where id=" + id;
            System.out.println("[execute][src/projectTodo/delete]执行"+sql);
            statement.executeUpdate(sql);
            System.out.println("[  end  ][src/projectTodo/delete]id为" + id +"的项目删除成功！");

            statement.close();
            conn.close();
            System.out.println("[  end  ][src/projectTodo/delete]statement与conn关闭。所有任务执行完毕。数据库关闭！！！");

        }
        catch (SQLException sqlexception)
        {
            System.out.println("[  fail ][src/projectTodo/delete]数据库访问出错："+sqlexception.getMessage());
            sqlexception.printStackTrace();
        }

        JSONObject resultJson = new JSONObject();
        try
        {
            resultJson.put("aaData", list);
            resultJson.put("result_code", 0);
            resultJson.put("result_msg", "ok");
        } catch (JSONException e)
        {
            e.printStackTrace();
        }

        response.setContentType("application/json; charset=UTF-8");

        try
        {
            response.getWriter().print(resultJson);
            response.getWriter().flush();
            response.getWriter().close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
