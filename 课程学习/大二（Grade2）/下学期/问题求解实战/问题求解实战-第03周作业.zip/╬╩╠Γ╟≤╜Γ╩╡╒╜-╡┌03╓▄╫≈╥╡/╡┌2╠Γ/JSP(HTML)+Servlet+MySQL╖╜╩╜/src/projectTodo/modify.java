package projectTodo;

import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class modify extends HttpServlet
{
    public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        request.setCharacterEncoding("UTF-8");

        // 获取请求参数
        String id = "".equals(request.getParameter("id")) ? null : request.getParameter("id");
        String parent_id = "".equals(request.getParameter("parent_id")) ? null : request.getParameter("parent_id");
        String object_id = "".equals(request.getParameter("object_id")) ? null : request.getParameter("object_id");
        String title = "".equals(request.getParameter("title")) ? null : request.getParameter("title");
        String content = "".equals(request.getParameter("content")) ? null : request.getParameter("content");
        String type = "".equals(request.getParameter("type")) ? null : request.getParameter("type");
        String limit_time = "".equals(request.getParameter("limit_time")) ? null : request.getParameter("limit_time");
        String end_tag = "".equals(request.getParameter("end_tag")) ? null : request.getParameter("end_tag");
        String begin_time = "".equals(request.getParameter("begin_time")) ? null : request.getParameter("begin_time");
        String end_time = "".equals(request.getParameter("end_time")) ? null : request.getParameter("end_time");
        String executor = "".equals(request.getParameter("executor")) ? null : request.getParameter("executor");
        String status = "".equals(request.getParameter("status")) ? null : request.getParameter("status");
        String attachment_name = "".equals(request.getParameter("attachment_name")) ? null : request.getParameter("attachment_name");
        String attachment_filename = "".equals(request.getParameter("attachment_filename")) ? null : request.getParameter("attachment_filename");
        String attachment_url = "".equals(request.getParameter("attachment_url")) ? null : request.getParameter("attachment_url");
        String attachment_size = "".equals(request.getParameter("attachment_size")) ? null : request.getParameter("attachment_size");
        String attachment_type = "".equals(request.getParameter("attachment_type")) ? null : request.getParameter("attachment_type");
        String qrcode_url = "".equals(request.getParameter("qrcode_url")) ? null : request.getParameter("qrcode_url");
        String qrcode_file_path_name = "".equals(request.getParameter("qrcode_file_path_name")) ? null : request.getParameter("qrcode_file_path_name");
        String top_tag = "".equals(request.getParameter("top_tag")) ? null : request.getParameter("top_tag");
        String priority = "".equals(request.getParameter("priority")) ? null : request.getParameter("priority");
        String user_id = "".equals(request.getParameter("user_id")) ? null : request.getParameter("user_id");
        String check_tag = "".equals(request.getParameter("check_tag")) ? null : request.getParameter("check_tag");
        String checker = "".equals(request.getParameter("checker")) ? null : request.getParameter("checker");
        String check_time = "".equals(request.getParameter("check_time")) ? null : request.getParameter("check_time");
        String used_tag = "".equals(request.getParameter("used_tag")) ? null : request.getParameter("used_tag");
        String creator = "".equals(request.getParameter("creator")) ? null : request.getParameter("creator");
        String creator_id = "".equals(request.getParameter("creator_id")) ? null : request.getParameter("creator_id");
        String create_time = "".equals(request.getParameter("create_time")) ? null : request.getParameter("create_time");

        // 打印日志
        System.out.println("[success][src/projectTodo/modify]: 收到id = " + id);
        System.out.println("[success][src/projectTodo/modify]: 收到parent_id = " + parent_id);
        System.out.println("[success][src/projectTodo/modify]: 收到object_id = " + object_id);
        System.out.println("[success][src/projectTodo/modify]: 收到title = " + title);
        System.out.println("[success][src/projectTodo/modify]: 收到content = " + content);
        System.out.println("[success][src/projectTodo/modify]: 收到type = " + type);
        System.out.println("[success][src/projectTodo/modify]: 收到limit_time = " + limit_time);
        System.out.println("[success][src/projectTodo/modify]: 收到end_tag = " + end_tag);
        System.out.println("[success][src/projectTodo/modify]: 收到begin_time = " + begin_time);
        System.out.println("[success][src/projectTodo/modify]: 收到end_time = " + end_time);
        System.out.println("[success][src/projectTodo/modify]: 收到executor = " + executor);
        System.out.println("[success][src/projectTodo/modify]: 收到status = " + status);
        System.out.println("[success][src/projectTodo/modify]: 收到attachment_name = " + attachment_name);
        System.out.println("[success][src/projectTodo/modify]: 收到attachment_filename = " + attachment_filename);
        System.out.println("[success][src/projectTodo/modify]: 收到attachment_url = " + attachment_url);
        System.out.println("[success][src/projectTodo/modify]: 收到attachment_size = " + attachment_size);
        System.out.println("[success][src/projectTodo/modify]: 收到attachment_type = " + attachment_type);
        System.out.println("[success][src/projectTodo/modify]: 收到qrcode_url = " + qrcode_url);
        System.out.println("[success][src/projectTodo/modify]: 收到qrcode_file_path_name = " + qrcode_file_path_name);
        System.out.println("[success][src/projectTodo/modify]: 收到top_tag = " + top_tag);
        System.out.println("[success][src/projectTodo/modify]: 收到priority = " + priority);
        System.out.println("[success][src/projectTodo/modify]: 收到user_id = " + user_id);
        System.out.println("[success][src/projectTodo/modify]: 收到check_tag = " + check_tag);
        System.out.println("[success][src/projectTodo/modify]: 收到checker = " + checker);
        System.out.println("[success][src/projectTodo/modify]: 收到check_time = " + check_time);
        System.out.println("[success][src/projectTodo/modify]: 收到used_tag = " + used_tag);
        System.out.println("[success][src/projectTodo/modify]: 收到creator = " + creator);
        System.out.println("[success][src/projectTodo/modify]: 收到creator_id = " + creator_id);
        System.out.println("[success][src/projectTodo/modify]: 收到create_time = " + create_time);

        try
        {
            // 加载数据库驱动
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("[success][src/projectTodo/modify]加载了驱动");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        List list = new ArrayList();
        try
        {
            // 连接数据库
            System.out.println("[  try  ][src/projectTodo/modify]开始链接数据库");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test?user=root&password=123456&useUnicode=true&characterEncoding=UTF-8"
            );
            System.out.println("[success][src/projectTodo/modify]链接数据库完毕");

            // 构建 SQL 更新语句
            String sql = "UPDATE project_todo SET " +
                    "parent_id = ?, object_id = ?, title = ?, content = ?, type = ?, limit_time = ?, " +
                    "end_tag = ?, begin_time = ?, end_time = ?, executor = ?, status = ?, attachment_name = ?, " +
                    "attachment_filename = ?, attachment_url = ?, attachment_size = ?, attachment_type = ?, " +
                    "qrcode_url = ?, qrcode_file_path_name = ?, top_tag = ?, priority = ?, user_id = ?, " +
                    "check_tag = ?, checker = ?, check_time = ?, used_tag = ?, creator = ?, creator_id = ?, " +
                    "create_time = ? " +
                    "WHERE id = ?";

            System.out.println("[execute][src/projectTodo/modify]执行 SQL: " + sql);

            // 使用 PreparedStatement 防止 SQL 注入
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // 设置参数值
            pstmt.setString(1, parent_id);
            pstmt.setString(2, object_id);
            pstmt.setString(3, title);
            pstmt.setString(4, content);
            pstmt.setString(5, type);
            pstmt.setString(6, limit_time);
            pstmt.setString(7, end_tag);
            pstmt.setString(8, begin_time);
            pstmt.setString(9, end_time);
            pstmt.setString(10, executor);
            pstmt.setString(11, status);
            pstmt.setString(12, attachment_name);
            pstmt.setString(13, attachment_filename);
            pstmt.setString(14, attachment_url);
            pstmt.setString(15, attachment_size);
            pstmt.setString(16, attachment_type);
            pstmt.setString(17, qrcode_url);
            pstmt.setString(18, qrcode_file_path_name);
            pstmt.setString(19, top_tag);
            pstmt.setString(20, priority);
            pstmt.setString(21, user_id);
            pstmt.setString(22, check_tag);
            pstmt.setString(23, checker);
            pstmt.setString(24, check_time);
            pstmt.setString(25, used_tag);
            pstmt.setString(26, creator);
            pstmt.setString(27, creator_id);
            pstmt.setString(28, create_time);
            pstmt.setString(29, id); // WHERE 条件

            // 执行 SQL
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("[success][src/projectTodo/modify]更新了 " + rowsAffected + " 条记录");

            // 关闭资源
            pstmt.close();
            conn.close();
            System.out.println("[  end  ][src/projectTodo/modify]statement与conn关闭。所有任务执行完毕。数据库关闭！！！");
        }
        catch (SQLException e)
        {
            System.out.println("[  fail ][src/projectTodo/modify]数据库访问出错：" + e.getMessage());
            e.printStackTrace();
        }

        // 重定向到列表页面
        JSONObject resultJson = new JSONObject();
        try
        {
            resultJson.put("aaData", list);
            resultJson.put("result_code", 0);
            resultJson.put("result_msg", "ok");
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        response.setContentType("application/json; charset=UTF-8");
        response.sendRedirect("projectTodo/file/projectTodo_list.html");
        try
        {
            response.getWriter().print(resultJson);
            response.getWriter().flush();
            response.getWriter().close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}