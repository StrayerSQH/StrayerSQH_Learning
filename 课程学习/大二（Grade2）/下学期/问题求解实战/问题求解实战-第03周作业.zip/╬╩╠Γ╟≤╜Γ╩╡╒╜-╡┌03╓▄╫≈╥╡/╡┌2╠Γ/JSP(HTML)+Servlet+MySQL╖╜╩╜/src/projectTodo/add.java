package projectTodo;

import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class add extends HttpServlet
{
    public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        request.setCharacterEncoding("UTF-8");
        String id = "".equals(request.getParameter("id")) ? null : request.getParameter("id");
        String parent_id = "".equals(request.getParameter("parent_id")) ? null : request.getParameter("parent_id");
        String object_id = "".equals(request.getParameter("object_id")) ? null : request.getParameter("object_id");
        String title = "".equals(request.getParameter("title")) ? null : request.getParameter("title");
        String content = "".equals(request.getParameter("content")) ? null : request.getParameter("content");
        String type = "".equals(request.getParameter("type")) ? null : request.getParameter("type");
        String limit_time = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        String end_tag = "".equals(request.getParameter("end_tag")) ? null : request.getParameter("end_tag");
        String begin_time = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        String end_time = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        String executor = "".equals(request.getParameter("executor")) ? null : request.getParameter("executor");
        String status = "".equals(request.getParameter("status")) ? null : request.getParameter("status");
        String attachment_name = "".equals(request.getParameter("attachment_name")) ? null : request.getParameter("attachment_name");
        String attachment_filename = "".equals(request.getParameter("attachment_filename")) ? null : request.getParameter("attachment_filename");
        String attachment_url = "".equals(request.getParameter("attachment_url")) ? null : request.getParameter("attachment_url");
        String attachment_size = "".equals(request.getParameter("attachment_size")) ? null : request.getParameter("attachment_size");
        String attachment_type = "".equals(request.getParameter("attachment_type")) ? null : request.getParameter("attachment_type");
        String qrcode_url = "".equals(request.getParameter("qrcode_url")) ? null : request.getParameter("qrcode_url");
        String qrcode_file_path_name = "".equals(request.getParameter("qrcode_file_path_name")) ? null : request.getParameter("qrcode_file_path_name");
        String top_tag = "".equals(request.getParameter("top_tag")) ? null : request.getParameter("top_tag");
        String priority = "".equals(request.getParameter("priority")) ? null : request.getParameter("priority");
        String user_id = "".equals(request.getParameter("user_id")) ? null : request.getParameter("user_id");
        String check_tag = "".equals(request.getParameter("check_tag")) ? null : request.getParameter("check_tag");
        String checker = "".equals(request.getParameter("checker")) ? null : request.getParameter("checker");
        String check_time = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        String used_tag = "".equals(request.getParameter("used_tag")) ? null : request.getParameter("used_tag");
        String creator = "".equals(request.getParameter("creator")) ? null : request.getParameter("creator");
        String creator_id = "".equals(request.getParameter("creator_id")) ? null : request.getParameter("creator_id");
        String create_time = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

        System.out.println("[success][src/projectTodo/add]: 收到id = " + id);
        System.out.println("[success][src/projectTodo/add]: 收到parent_id = " + parent_id);
        System.out.println("[success][src/projectTodo/add]: 收到object_id = " + object_id);
        System.out.println("[success][src/projectTodo/add]: 收到title = " + title);
        System.out.println("[success][src/projectTodo/add]: 收到content = " + content);
        System.out.println("[success][src/projectTodo/add]: 收到type = " + type);
        System.out.println("[success][src/projectTodo/add]: 收到limit_time = " + limit_time);
        System.out.println("[success][src/projectTodo/add]: 收到end_tag = " + end_tag);
        System.out.println("[success][src/projectTodo/add]: 收到begin_time = " + begin_time);
        System.out.println("[success][src/projectTodo/add]: 收到end_time = " + end_time);
        System.out.println("[success][src/projectTodo/add]: 收到executor = " + executor);
        System.out.println("[success][src/projectTodo/add]: 收到status = " + status);
        System.out.println("[success][src/projectTodo/add]: 收到attachment_name = " + attachment_name);
        System.out.println("[success][src/projectTodo/add]: 收到attachment_filename = " + attachment_filename);
        System.out.println("[success][src/projectTodo/add]: 收到attachment_url = " + attachment_url);
        System.out.println("[success][src/projectTodo/add]: 收到attachment_size = " + attachment_size);
        System.out.println("[success][src/projectTodo/add]: 收到attachment_type = " + attachment_type);
        System.out.println("[success][src/projectTodo/add]: 收到qrcode_url = " + qrcode_url);
        System.out.println("[success][src/projectTodo/add]: 收到qrcode_file_path_name = " + qrcode_file_path_name);
        System.out.println("[success][src/projectTodo/add]: 收到top_tag = " + top_tag);
        System.out.println("[success][src/projectTodo/add]: 收到priority = " + priority);
        System.out.println("[success][src/projectTodo/add]: 收到user_id = " + user_id);
        System.out.println("[success][src/projectTodo/add]: 收到check_tag = " + check_tag);
        System.out.println("[success][src/projectTodo/add]: 收到checker = " + checker);
        System.out.println("[success][src/projectTodo/add]: 收到check_time = " + check_time);
        System.out.println("[success][src/projectTodo/add]: 收到used_tag = " + used_tag);
        System.out.println("[success][src/projectTodo/add]: 收到creator = " + creator);
        System.out.println("[success][src/projectTodo/add]: 收到creator_id = " + creator_id);
        System.out.println("[success][src/projectTodo/add]: 生成create_time = " + create_time);


        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("[success][src/projectTodo/add]加载了驱动");
        }
        catch (ClassNotFoundException classnotfoundexception)
        {
            classnotfoundexception.printStackTrace();
        }

        try {
            System.out.println("[  try  ][src/projectTodo/add]开始链接数据库");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test?user=root&password=123456&useUnicode=true&characterEncoding=UTF-8"
            );
            System.out.println("[success][src/projectTodo/add]链接数据库完毕");

            // 使用 PreparedStatement 代替 Statement
            String sql = "INSERT INTO project_todo (" +
                    "id, parent_id, object_id, title, content, type, limit_time, end_tag, begin_time, end_time, " +
                    "executor, status, attachment_name, attachment_filename, attachment_url, attachment_size, " +
                    "attachment_type, qrcode_url, qrcode_file_path_name, top_tag, priority, user_id, check_tag, " +
                    "checker, check_time, used_tag, creator, creator_id, create_time" +
                    ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            System.out.println("[execute][src/projectTodo/add]执行 SQL: " + sql);

            PreparedStatement pstmt = conn.prepareStatement(sql);

            // 设置参数值
            pstmt.setString(1, id);
            pstmt.setString(2, parent_id);
            pstmt.setString(3, object_id);
            pstmt.setString(4, title);
            pstmt.setString(5, content);
            pstmt.setString(6, type);
            pstmt.setString(7, limit_time);
            pstmt.setString(8, end_tag);
            pstmt.setString(9, begin_time);
            pstmt.setString(10, end_time);
            pstmt.setString(11, executor);
            pstmt.setString(12, status);
            pstmt.setString(13, attachment_name);
            pstmt.setString(14, attachment_filename);
            pstmt.setString(15, attachment_url);
            pstmt.setString(16, attachment_size);
            pstmt.setString(17, attachment_type);
            pstmt.setString(18, qrcode_url);
            pstmt.setString(19, qrcode_file_path_name);
            pstmt.setString(20, top_tag);
            pstmt.setString(21, priority);
            pstmt.setString(22, user_id);
            pstmt.setString(23, check_tag);
            pstmt.setString(24, checker);
            pstmt.setString(25, check_time);
            pstmt.setString(26, used_tag);
            pstmt.setString(27, creator);
            pstmt.setString(28, creator_id);
            pstmt.setString(29, create_time);

            // 执行 SQL
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("[success][src/projectTodo/add]插入了 " + rowsAffected + " 条记录");

            pstmt.close();
            conn.close();
            System.out.println("[  end  ][src/projectTodo/add]statement与conn关闭。所有任务执行完毕。数据库关闭！！！");
        }
        catch (SQLException sqlexception) {
            System.out.println("[  fail ][src/projectTodo/add]数据库访问出错：" + sqlexception.getMessage());
            sqlexception.printStackTrace();
        }
        response.sendRedirect("projectTodo/file/projectTodo_list.html");
    }
}
