package upload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class GetUploadDataServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // 从 session 中获取数据
        String title = (String) request.getSession().getAttribute("title");
        String content = (String) request.getSession().getAttribute("content");
        String memo = (String) request.getSession().getAttribute("memo");
        String attachment = (String) request.getSession().getAttribute("attachment");
        String photo = (String) request.getSession().getAttribute("photo");

        // 手动拼接 JSON 字符串
        String jsonResponse = String.format(
                "{\"title\":\"%s\", \"content\":\"%s\", \"memo\":\"%s\", \"attachment\":\"%s\", \"photo\":\"%s\"}",
                escapeJson(title), escapeJson(content), escapeJson(memo), escapeJson(attachment), escapeJson(photo)
        );

        // 设置响应类型为 JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse);
    }

    // 处理特殊字符以确保 JSON 格式正确
    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}
