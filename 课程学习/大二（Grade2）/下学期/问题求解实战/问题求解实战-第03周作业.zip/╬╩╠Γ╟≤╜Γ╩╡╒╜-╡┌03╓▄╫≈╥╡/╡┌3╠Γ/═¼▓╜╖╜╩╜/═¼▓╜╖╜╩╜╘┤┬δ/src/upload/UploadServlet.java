package upload;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import java.io.File;
import java.io.IOException;

@MultipartConfig
public class UploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // 获取表单字段的值
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String memo = request.getParameter("memo");

        // 处理文件上传
        Part attachment = request.getPart("attachment");
        Part photo = request.getPart("photo");

        // 保存文件到指定目录 (如在项目根目录的 uploads 文件夹中)
        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        // 解析文件名（替代 getSubmittedFileName 方法）
        String attachmentFileName = getFileName(attachment);
        String photoFileName = getFileName(photo);

        // 保存文件
        attachment.write(uploadPath + File.separator + attachmentFileName);
        photo.write(uploadPath + File.separator + photoFileName);

        // 将数据保存到 session 中
        request.getSession().setAttribute("title", title);
        request.getSession().setAttribute("content", content);
        request.getSession().setAttribute("memo", memo);
        request.getSession().setAttribute("attachment", "uploads/" + attachmentFileName);
        request.getSession().setAttribute("photo", "uploads/" + photoFileName);

        // 重定向到结果页面
        response.sendRedirect("form-fileupload-result.html");
    }

    // 自定义方法来解析 Part 的 Content-Disposition 头部，提取文件名
    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        if (contentDisposition != null) {
            // content-disposition 示例: form-data; name="file"; filename="file.txt"
            for (String cd : contentDisposition.split(";")) {
                if (cd.trim().startsWith("filename")) {
                    // 去掉文件名前后的引号
                    return cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
                }
            }
        }
        return null;
    }
}
