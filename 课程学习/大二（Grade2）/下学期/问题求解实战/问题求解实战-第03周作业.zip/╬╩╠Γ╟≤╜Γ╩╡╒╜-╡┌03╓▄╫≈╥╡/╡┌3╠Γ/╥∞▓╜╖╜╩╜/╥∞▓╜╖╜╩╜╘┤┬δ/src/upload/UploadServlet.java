package upload;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;

@MultipartConfig
public class UploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 获取表单数据
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String memo = request.getParameter("memo");

        // 获取文件
        Part attachment = request.getPart("attachment");
        Part photo = request.getPart("photo");

        // 设置上传目录
        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        // 获取文件名
        String attachmentFileName = getFileName(attachment);
        String photoFileName = getFileName(photo);

        // 保存文件到服务器
        attachment.write(uploadPath + File.separator + attachmentFileName);
        photo.write(uploadPath + File.separator + photoFileName);

        // 获取文件大小（字节）
        long attachmentSize = attachment.getSize();
        long photoSize = photo.getSize();

        // 将字节转换为 KB
        double attachmentSizeKB = attachmentSize / 1024.0;
        double photoSizeKB = photoSize / 1024.0;

        // 生成可访问的URL
        String serverUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
        String attachmentUrl = serverUrl + "/uploads/" + attachmentFileName;
        String photoUrl = serverUrl + "/uploads/" + photoFileName;

        // 返回JSON响应
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(
                "{\"title\":\"" + title + "\"," +
                        "\"content\":\"" + content + "\"," +
                        "\"memo\":\"" + memo + "\"," +
                        "\"attachment\":\"" + attachmentUrl + "\"," +
                        "\"photo\":\"" + photoUrl + "\"," +
                        "\"photoUrl\":\"" + "http://localhost:8087/Fileupload2_war_exploded/uploads/" + photoFileName + "\"," +
                        "\"uploadPath\":\"" + "D:/问题求解实战-第03周作业/第3题/异步方式/异步方式源码/out/artifacts/Fileupload2_war_exploded/uploads" + "\"," +
                        "\"photoSize\":\"" + String.format("%.2f", photoSizeKB) + "KB\"}"
        );
    }

    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return null;
    }
}